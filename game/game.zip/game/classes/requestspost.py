import requests

my_data = {'name':'Nick', 'email': 'nick@example.com'}
r = requests.post('https://www.w3schools.com/php/demo_form_post.php', data = my_data)

f = open('myfile.html', 'w+')
f.write(r.text)
